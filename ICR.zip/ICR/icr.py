import os
import uuid

import cv2
from datetime import datetime
from flask import Flask, request, render_template

from cheque_module.main import infer_by_web
from cheque_module.extraction_cheque_1 import line_list as line_list_c1
from cheque_module.extraction_cheque_2 import line_list as line_list_c2

from full_doc_module.data.extractor_doc_1 import get_line_images as get_line_images_for_doc1
from full_doc_module.data.extractor_doc_2 import get_line_images as get_line_images_for_doc2

from full_doc_module.main import predict_for_line_image
from common.SpellChecker import correct_sentence

from flask import jsonify

__author__ = 'user'

from common.utils import pdf2img

app = Flask(__name__)

APP_ROOT = os.path.dirname(os.path.abspath(__file__))  # project abs path


@app.route("/upload/cheque1", methods=["POST"])
def upload_cheque1():
    try:
        file_name, file_path = receive_payload()

        img_path = pdf2img(file_path)[0]
        img = cv2.imread(img_path)
        new = (1220, 483)
        img = cv2.resize(img, new, interpolation = cv2.INTER_CUBIC)
        a = line_list_c1(img)[0]

        b = line_list_c1(img)[1]
        line = infer_by_web(a)
        line1 = infer_by_web(b)
        result = line + "\n" + line1
        return jsonify(result=result , response=200)
    except Exception as e:
        return "Something went wrong. Error is " + str(e)
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


@app.route("/upload/cheque2", methods=["POST"])
def upload_cheque2():
    try:
        file_name, file_path = receive_payload()

        img_path = pdf2img(file_path)[0]
        img = cv2.imread(img_path)
        new = (524, 247)
        img = cv2.resize(img, new, interpolation = cv2.INTER_CUBIC)
        line_ = ""
        list_ = line_list_c2(img)

        for i in range(len(list_)):
            line_ += infer_by_web(list_[i]) + "\n"

        result = line_
        return jsonify(result=result , response=200)
    except Exception as e:
        return "Something went wrong. Error is " + str(e)
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


@app.route("/upload/doc1", methods=["POST"])
def upload_doc1():
    global img_paths
    try:
        file_name, file_path = receive_payload()

        img_paths = pdf2img(file_path)
        img = cv2.imread(img_paths[0])
        new = (465, 528)
        img1 = cv2.resize(img, new, interpolation=cv2.INTER_CUBIC)
        line_imgs = get_line_images_for_doc1(img1)
        line_img_output_dir_path = 'full_doc_module/output/line_imgs'
        for line_img in line_imgs:
            file_path = os.path.join(line_img_output_dir_path, 'doc_') + str(uuid.uuid4()) + '.jpg'
            cv2.imwrite(file_path,line_img)
        pred = predict_for_line_image(line_imgs)
        result = correct_sentence(pred)

        return jsonify(result=result , response=200)
    except Exception as e:
        return "Something went wrong. Error is " + str(e)
    finally:
        if os.path.exists(img_paths[0]):
            os.remove(img_paths[0])
        if os.path.exists(file_path):
            os.remove(file_path)


@app.route("/upload/doc2", methods=["POST"])
def upload_doc2():
    global img_paths
    try:
        file_name, file_path = receive_payload()

        img_paths = pdf2img(file_path)
        img = cv2.imread(img_paths[0])
        new = (722, 563)
        img1 = cv2.resize(img, new, interpolation=cv2.INTER_CUBIC)
        line_imgs = get_line_images_for_doc2(img1)
        pred = predict_for_line_image(line_imgs)
        result = correct_sentence(pred)

        return jsonify(result=result , response=200)
    except Exception as e:
        return "Something went wrong. Error is " + str(e)
    finally:
        if os.path.exists(img_paths[0]):
            os.remove(img_paths[0])
        if os.path.exists(file_path):
            os.remove(file_path)


def receive_payload():
    # folder_name = request.form['uploads']
    target = os.path.join(APP_ROOT, 'static/')
    print(target)
    if not os.path.isdir(target):
        os.mkdir(target)
    print(request.files.getlist("file"))
    option = request.form.get('optionsPrediction')
    print("Selected Option:: {}".format(option))
    for upload in request.files.getlist("file"):
        print(upload)
        print("{} is the file name".format(upload.filename))
        filename = upload.filename
        # This is to verify files are supported
        ext = os.path.splitext(filename)[1]
        if (ext == ".jpg") or (ext == ".png") or (ext == ".pdf"):
            print("File supported moving on...")
        else:
            render_template("Error.html", message="Files uploaded are not supported...")
        file_name = datetime.now().strftime('%Y-%m-%d_%H_%M_%S') + "." + ext
        file_path = "/".join([target, file_name])
        print("Accept incoming file:", filename)
        print("Save it to:", file_path)
        upload.save(file_path)
    return file_name, file_path


if __name__ == "__main__":
    app.run(port=4555, debug=True)
