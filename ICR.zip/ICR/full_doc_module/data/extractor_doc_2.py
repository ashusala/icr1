import numpy as np
import pandas as pd
import cv2


def enhance(img):
    dst = cv2.detailEnhance(img, sigma_s=10, sigma_r=0.15)
    return dst


def img2gray(img):
    gray = cv2.cvtColor(enhance(img), cv2.COLOR_BGR2GRAY)
    return gray


def findHorizontalLines(img):
    gray = img2gray(img)

    # set threshold to remove background noise
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    kernel = np.ones((5, 3), np.uint8)
    dilate = cv2.dilate(thresh, kernel, iterations=1)

    # define rectangle structure (line) to look for: width 100, hight 1. This is a
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (100, 5))

    # Find horizontal lines
    lineLocations = cv2.morphologyEx(dilate, cv2.MORPH_OPEN, horizontal_kernel, iterations=1)

    kernel1 = np.ones((5, 6), np.uint8)
    erosion = cv2.erode(lineLocations, kernel1, iterations=1)

    return erosion


def dataframe(img):
    lineLocations = (findHorizontalLines(img) / 255).astype(np.uint8)
    df_lineLocations = pd.DataFrame(lineLocations.sum(axis=1)).reset_index()
    df_lineLocations.columns = ['rowLoc', 'LineLength']
    df = df_lineLocations[df_lineLocations['LineLength'] > 0]

    return df, lineLocations


def col_st(img):
    df, lineLocations = dataframe(img)
    col_st_list = []
    for i in df.index:
        for j in range(lineLocations.shape[1]):
            if lineLocations[i, j] == 1:
                col_st_list.append(j)
                break
    return col_st_list


def cropped(img):
    img_gray = img2gray(img)
    df, linelocations = dataframe(img)
    col_st_list = col_st(img)
    list_cropped = []
    for i in range(len(df)):
        row = df.iloc[i][0]
        col_start = col_st_list[i]
        length = 590
        col_end = col_start + length
        list_cropped.append(img_gray[row + 15:row + 525, col_start - 20:col_end])
    return list_cropped[0]


def get_line_images_core(img):
    a = cropped(img)
    text = cv2.copyMakeBorder(a, 15, 15, 15, 15, cv2.BORDER_CONSTANT, value=255)

    thresh1 = cv2.threshold(text, 0, 255, cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)[1]
    rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (40, 5))
    dilation = cv2.dilate(thresh1, rect_kernel, iterations=1)

    contours, hierarchy = cv2.findContours(dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    word_imgs = []

    im2 = text.copy()
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)

        img = im2[y:y + h, x:x + w]
        #         constant= cv2.copyMakeBorder(img,15,15,15,15,cv2.BORDER_CONSTANT,value=255)

        word_imgs.append(img)

    return word_imgs


def get_line_images(img):
    lines = get_line_images_core(img)
    arr = []
    for i in range(len(lines)):
        if i != 4:
            arr.append(lines[i])
        else:
            arr2 = lines[i][:56, :]
            arr1 = lines[i][56:, :]
            arr.append(arr1)
            arr.append(arr2)
    return arr
