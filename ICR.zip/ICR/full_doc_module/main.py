
import os
import string

from full_doc_module.data import preproc as pp
from full_doc_module.data.generator import Tokenizer
from full_doc_module.network.model import HTRModel
from autocorrect import Speller

spell = Speller(lang='en')

raw_path = os.path.join("full_doc_module/raw", "iam")
source_path = os.path.join("full_doc_module/data", f"iam.hdf5")
output_path = os.path.join("full_doc_module/output", "iam", "flor")
target_path = os.path.join(output_path, "checkpoint_weights.hdf5")

input_size = (1024, 128, 1)
max_text_length = 128
charset_base = string.printable[:95]


def predict_for_line_image(arr):
    line_arr = ""
    for image in reversed(arr):

        tokenizer = Tokenizer(chars=charset_base, max_text_length=max_text_length)
        img = pp.preprocess(image, input_size=input_size)
        x_test = pp.normalization([img])

        model = HTRModel(architecture="flor",
                         input_size=input_size,
                         vocab_size=tokenizer.vocab_size,
                         beam_width=10,
                         top_paths=10)

        model.compile(learning_rate=0.001)
        model.load_checkpoint(target=target_path)

        predicts, probabilities = model.predict(x_test, ctc_decode=True)
        predicts = [[tokenizer.decode(x) for x in y] for y in predicts]

        a = []
        for i, (pred, prob) in enumerate(zip(predicts, probabilities)):
            for (pd, pb) in zip(pred, prob):
                a.append(pd)

        line_arr += a[0] + " "
    return line_arr