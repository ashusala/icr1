from pdf2image import convert_from_path
import uuid
import os


def pdf2img(path):
    images = convert_from_path(path, poppler_path=r"C:\poppler-21.11.0\Library\bin")
    pdf_img_output_dir_path = 'full_doc_module/output/pdf2img_output'
    file_paths = []

    if not os.path.exists(pdf_img_output_dir_path):
        os.mkdir(pdf_img_output_dir_path)

    for i in range(len(images)):
        file_path = os.path.join(pdf_img_output_dir_path, 'doc_') + str(uuid.uuid4()) + '.jpg'
        images[i].save(file_path, 'JPEG')
        file_paths.append(file_path)

    print("pdf to image file_paths are :", file_paths)

    return file_paths
