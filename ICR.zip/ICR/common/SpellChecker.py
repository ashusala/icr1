from autocorrect import Speller

spell = Speller('en')


def correct_sentence(line):
    lines = line.strip().split(' ')
    new_line = ""
    for l in lines:
        if l.upper() == l:
            new_line += l + " "
        else:
            new_line += spell(l) + " "
    return new_line
