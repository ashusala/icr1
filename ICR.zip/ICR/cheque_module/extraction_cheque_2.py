import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cv2


def img2gray(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return gray


def findHorizontalLines(img):
    gray = img2gray(img)

    # set threshold to remove background noise
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    kernel = np.ones((3, 3), np.uint8)
    dilate = cv2.dilate(thresh, kernel, iterations=1)

    # define rectangle structure (line) to look for: width 100, hight 1. This is a
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (70, 1))

    # Find horizontal lines
    lineLocations = cv2.morphologyEx(dilate, cv2.MORPH_OPEN, horizontal_kernel, iterations=1)

    kernel1 = np.ones((3, 3), np.uint8)
    erosion = cv2.erode(lineLocations, kernel1, iterations=1)

    return erosion


def dataframe(img):
    lineLocations = (findHorizontalLines(img) / 255).astype(np.uint8)
    df_lineLocations = pd.DataFrame(lineLocations.sum(axis=1)).reset_index()
    df_lineLocations.columns = ['rowLoc', 'LineLength']
    df = df_lineLocations[df_lineLocations['LineLength'] > 0]

    return df, lineLocations


def col_st(img):
    df, lineLocations = dataframe(img)
    col_st_list = []
    for i in df.index:
        for j in range(lineLocations.shape[1]):
            if lineLocations[i, j] == 1:
                col_st_list.append(j)
                break
    return col_st_list


def mask_n_crop(img):
    img_gray = img2gray(img)
    df, linelocations = dataframe(img)
    col_st_list = col_st(img)
    list_cropped = []
    for i in range(len(df)):
        row = df.iloc[i][0]
        col_start = col_st_list[i]
        length = df.iloc[i][1]
        col_end = col_start + length
        list_cropped.append(img_gray[row - 20:row + 5, col_start:col_end - 1])
    return list_cropped


def remove_line(img):
    list_cropped_imgs = mask_n_crop(img)

    lines_removed = []

    for gray in list_cropped_imgs:
        if (gray.shape[0] != 0):
            scale_percent = 300  # percent of original size
            width = int(gray.shape[1] * scale_percent / 100)
            height = int(gray.shape[0] * scale_percent / 100)
            dim = (width, height)

            # resize image
            gray = cv2.resize(gray, dim, interpolation=cv2.INTER_CUBIC)

            thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

            # Remove horizontal
            horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (50, 1))
            detected_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel, iterations=2)
            cnts = cv2.findContours(detected_lines, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            cnts = cnts[0] if len(cnts) == 2 else cnts[1]
            for c in cnts:
                cv2.drawContours(gray, [c], -1, (255, 255, 255), 2)

            # Repair image
            repair_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 6))
            result = 255 - cv2.morphologyEx(255 - gray, cv2.MORPH_CLOSE, repair_kernel, iterations=1)
            lines_removed.append(result)
    return lines_removed


def binarize(img):
    list_line_removed = remove_line(img)
    binarized = []

    for i in range(len(list_line_removed)):
        f = 255 * (np.round(list_line_removed[i] / 255).astype(np.uint8))
        alpha = 1.5
        beta = 0

        adjusted = cv2.convertScaleAbs(f, alpha=alpha, beta=beta)

        binarized.append(adjusted)

    return binarized


def line_list(img):
    l = []
    line3 = binarize(img)[8][:, 10:640]
    line4 = binarize(img)[9][:, :420]
    line1 = binarize(img)[5][:, 40:490]
    list_lines = [line1, line3, line4]
    for i in range(len(list_lines)):
        l.append(cv2.copyMakeBorder(list_lines[i], 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=255))
    return l
