import cv2
import numpy as np

from cheque_module.DataLoader import Batch, FilePaths
from cheque_module.SamplePreprocessor import preprocessor
from cheque_module.Model import DecoderType, Model
from cheque_module.SpellChecker import correct_sentence


def load_different_image():
    imgs = []
    for i in range(1, Model.batchSize):
       imgs.append(preprocessor(cv2.imread("cheque_module/data/check_image/a ({}).png".format(i), cv2.IMREAD_GRAYSCALE), Model.imgSize, enhance=False))
    return imgs


def generate_random_images():
    return np.random.random((Model.batchSize, Model.imgSize[0], Model.imgSize[1]))


def infer(model, fnImg):
    """ Recognize text in image provided by file path """

    img = preprocessor(fnImg, imgSize=Model.imgSize)
    if img is None:
        print("Image not found")

    imgs = load_different_image()
    imgs = [img] + imgs
    batch = Batch(None, imgs)
    recognized = model.inferBatch(batch)  # recognize text

    print("Without Correction", recognized[0])
    print("With Correction", correct_sentence(recognized[0]))
    return correct_sentence(recognized[0])


# def main():
#     """ Main function """
#     # Opptional command line args
#     parser = argparse.ArgumentParser()
#     print(parser)
#     parser.add_argument(
#         "--wordbeamsearch", help="use word beam search instead of best path decoding", action="store_true")
#     args = parser.parse_args()
#
#     decoderType = DecoderType.BestPath
#     if args.wordbeamsearch:
#         decoderType = DecoderType.WordBeamSearch


def infer_by_web(path):
    decoderType = DecoderType.BestPath
    print(open(FilePaths.fnAccuracy).read())
    model = Model(open(FilePaths.fnCharList).read(),
                  decoderType, mustRestore=False)
    recognized = infer(model, path)

    return recognized


if __name__ == '__main__':
    main()
