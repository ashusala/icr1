import numpy as np
import cv2


def img2gray(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    im = gray[90:250, 80:1100]
    return im


def binarize(img):
    img = img2gray(img)

    f = 255 * (np.round(img / 255).astype(np.uint8))
    f = cv2.bitwise_not(f)
    kernel = np.ones((2, 1), np.uint8)
    dilation = cv2.bitwise_not(cv2.dilate(f, kernel, iterations=1))

    return dilation


def line_list(img):
    line1 = binarize(img)[10:60, 60:390]
    line2 = binarize(img)[55:140, 120:670]
    list_lines = [line1, line2]
    return list_lines
